package com.alex.sms.views;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.alex.sms.repository.SchoolRepository;


// TODO: Auto-generated Javadoc
/**
 * The Class ViewsController.
 */
@Controller
@RequestMapping
public class ViewsController {

	@Autowired
	private SchoolRepository schoolRepository;
	

	
	/**
	 * Index.
	 *
	 * @param model the model
	 * @return the string
	 */
	@GetMapping("/")
	public String index(Model model) {

        model.addAttribute("schools", schoolRepository.findAll());

		return "index";
	}
	
	/**
	 * Error 404.
	 *
	 * @return the string
	 */
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	public String error404() {
		return "error/404";
	}
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
}
